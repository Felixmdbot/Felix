/*
* Nama Pengembang: Sazumi Viki
* Kontak Whatsapp: wa.me/6285236226786
* Kontak Telegram: t.me/sazumiviki
* Akun Github: github.com/SazumiVicky
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

/* const axios = require("axios");
const uploadImage = require("../lib/uploadImage");

let handler = m => m
handler.before = async (m, { conn }) => {
  let chat = global.db.data.chats[m.chat]
  let mime = (m.msg || m).mimetype || "";
  if (chat.antiPorn) {
    if (/image|webp/.test(mime)) {
      conn.chatRead(m.chat);
      let img = await m.download();
      let imageUrl = await uploadImage(img);
      try {
        let api = `https://api.lolhuman.xyz/api/nsfwcheck?apikey=${global.lolkey}&img=${encodeURIComponent(
          imageUrl
        )}`;
        let { data } = await axios.get(api);
        let status = data.status;
        if (status === 200) {
          let score = data.result;
          if (score >= 0.7041017031669617) {
            let user = m.sender;
            let mention = `@${user.replace(/@.+/, "")}`;
            await conn.reply(
              m.chat,
              `🐱 ${mention} Detected sending NSFW`,
              m
            );
            await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant } })
          }
        }
      } catch (e) {
        console.log(e);
        conn.reply(m.chat, "Error!", m);
      }
    }
  };
}

module.exports = handler;
*/